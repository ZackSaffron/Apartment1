//
//  ResidenceViewModel.swift
//  Apartments
//
//  Created by admin on 7/26/22.
//

import Foundation

class ResidenceViewModel: ObservableObject {
    @Published var address: String = ""
}
