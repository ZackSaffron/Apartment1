//
//  ApartmentViewModel.swift
//  Apartments
//
//  Created by admin on 7/26/22.
//

import Foundation

class ApartmentViewModel: ObservableObject {
    @Published var apartments: [Apartment] = []
    
    func getData() {
        guard let apiUrl = URL(string: "https://mocki.io/v1/7f401311-4e44-4f24-9a6a-42699e2ac458") else { return }
        let task = URLSession.shared.dataTask(with: apiUrl){[weak self] data, response, error in
            guard let data = data else {
                print("error")
                return
            }
            do {
                let result = try JSONDecoder().decode([Apartment].self, from: data)
                DispatchQueue.main.async {
                    self?.apartments = result.sorted { $0.rentAmount < $1.rentAmount }
                }
            } catch {
                print("error decoding")
            }
        }
        task.resume()
    }
}
