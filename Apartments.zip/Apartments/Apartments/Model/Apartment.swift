//
//  Apartment.swift
//  Apartments
//
//  Created by admin on 7/26/22.
//

import Foundation

struct Apartment: Hashable, Codable {
    let aprtName: String
    let floorType: String
    let areaInSQFT: Int
    let numberOfBedrooms: Int
    let numberOfBathrooms: Double
    let rentAmount: Double
    let apartments: [Residence]
    
    enum CodingKeys: String, CodingKey {
        case aprtName = "aptName"
        case areaInSQFT = "area"
        case rentAmount = "rentPerMonth"
        case floorType, numberOfBedrooms, numberOfBathrooms, apartments
    }
}

struct Residence: Hashable, Codable {
    let aptAdress: String
    
    enum CodingKeys: String, CodingKey {
        case aptAdress
    }
}
