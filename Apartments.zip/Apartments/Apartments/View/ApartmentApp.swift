//
//  ApartmentApp.swift
//  Apartments
//
//  Created by admin on 7/26/22.
//

import SwiftUI

@main
struct ApartmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
