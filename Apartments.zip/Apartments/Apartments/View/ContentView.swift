//
//  ContentView.swift
//  Apartments
//
//  Created by admin on 7/26/22.
//

import SwiftUI

struct ContentView: View {
    @StateObject var apartment = ApartmentViewModel()
    var body: some View {
        NavigationView {
            List {
                ForEach(apartment.apartments, id: \.self){ apartment in
                    HStack {
                        NavigationLink(destination: ApartmentView(apartments: apartment.apartments, apartmentName: apartment.aprtName)) {
                            VStack {
                            Text(apartment.aprtName)
                                Text(apartment.floorType)
                                Text("Square foot area " + String(apartment.areaInSQFT))
                                Text("Number of Bedrooms " + String(apartment.numberOfBedrooms))
                                Text("Number of Bathrooms " + String(apartment.numberOfBathrooms))
                                Text("Rent " + String(apartment.rentAmount))
                            }.buttonStyle(PlainButtonStyle())
                        }
                    }
                }
            }
            .navigationTitle("Rental Apartments")
            .onAppear {
                apartment.getData()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
