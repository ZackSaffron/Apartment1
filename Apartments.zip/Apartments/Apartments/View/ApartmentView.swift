//
//  ApartmentView.swift
//  Apartments
//
//  Created by admin on 7/26/22.
//

import SwiftUI

struct ApartmentView: View {
    var apartments = [Residence]()
    var apartmentName = ""
    
    var body: some View {
        List {
            ForEach(apartments, id: \.self){ apartment in
                HStack {
                    Text("Address " + apartment.aptAdress)
                    
                }
            }
            .navigationTitle(apartmentName)
        }
    }
}

struct ApartmentView_Previews: PreviewProvider {
    static var previews: some View {
        ApartmentView()
    }
}
